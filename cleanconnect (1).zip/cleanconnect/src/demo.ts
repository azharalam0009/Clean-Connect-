import { useEffect, useRef, useState } from "react";
export const STEPS: [string, string][] = [
 ["Citizen reports drainage issue", "Ananya files “Blocked drain”, Ward 12"],
 ["Location selected on GPS map", "Pin dropped near Sector 4 market"],
 ["Nearby verified worker assigned", "Ravi K. · Govt ID Verified · 0.9 km · ETA 6 min"],
 ["Worker accepts", "Status: Accepted"],
 ["Live map tracking", "Status: On the Way · optimised route"],
 ["Arrived → Work Started", "SLA timer paused, proof capture on"],
 ["Completed with before/after proof", "Geo-tagged photos (queued offline, sync later)"],
 ["Supervisor verifies", "Meena S. approves proof"],
 ["Citizen rates service", "★★★★★ 5.0"],
 ["Analytics updated", "Resolved +1 · response time improves · hotspot flagged"]];
export function useDemo() {
  const [step, setStep] = useState(0); const [playing, setPlaying] = useState(false);
  const t = useRef<number>();
  useEffect(() => { if (!playing) return; t.current = window.setInterval(() => setStep(s => { if (s >= 10) { setPlaying(false); return s; } return s + 1; }), 2600); return () => clearInterval(t.current); }, [playing]);
  return { step, next: () => setStep(s => Math.min(10, s + 1)), set: (n: number) => setStep(s => Math.max(s, n)), playing, toggle: () => { if (step >= 10) setStep(0); setPlaying(p => !p); }, reset: () => { setPlaying(false); setStep(0); } };
}
