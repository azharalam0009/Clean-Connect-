import { useState } from "react";
import { Leaf, User, HardHat, ShieldCheck, BarChart3, Home, Play, Pause, RotateCcw, BadgeCheck, Brain, WifiOff, Wifi, Timer, Navigation, Star } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from "recharts";
import CityMap, { END } from "./CityMap";
import { STEPS, useDemo } from "./demo";
type D = ReturnType<typeof useDemo>;
const TABS = [["home", "Home", Home], ["citizen", "Citizen", User], ["worker", "Worker", HardHat], ["sup", "Supervisor", ShieldCheck], ["admin", "Admin", BarChart3]] as const;
const Timeline = ({ d }: { d: D }) => (
  <ol className="space-y-2">{STEPS.map(([t, s], i) => { const done = i < d.step - 1, cur = i === d.step - 1; return (
    <li key={t} className={`flex gap-3 ${done || cur ? "" : "opacity-50"}`}><span className={`h-6 w-6 shrink-0 rounded-full grid place-items-center text-xs ${done ? "bg-brand text-white" : cur ? "bg-saffron" : "bg-slate-200 text-slate-600"}`}>{done ? "✓" : i + 1}</span>
      <div><p className={cur ? "font-semibold" : ""}>{t}</p><p className="text-sm text-slate-500">{s}</p></div></li>); })}</ol>);
const Controls = ({ d }: { d: D }) => (
  <div className="flex flex-wrap gap-2 my-3"><button className="btn pri" onClick={d.next} disabled={d.step >= 10}>{d.step ? "Next step →" : "▶ Start Demo Mode"}</button>
    <button className="btn" onClick={d.toggle}>{d.playing ? <Pause className="inline h-4 w-4" /> : <Play className="inline h-4 w-4" />} Auto-play</button>
    <button className="btn" onClick={d.reset}><RotateCcw className="inline h-4 w-4" /> Reset</button></div>);
const Kpi = ({ v, l }: { v: string | number; l: string }) => <div className="card"><b className="text-3xl text-brand">{v}</b><p className="text-sm text-slate-500">{l}</p></div>;
const Chip = ({ children, warn }: { children: React.ReactNode; warn?: boolean }) => <span className={`chip ${warn ? "!bg-red-100 !text-red-800" : ""}`}>{children}</span>;
function HomeV({ d, go }: { d: D; go: (v: string) => void }) {
  const done = d.step >= 10 ? 1 : 0;
  return (<>
    <section className="py-10"><span className="chip">Independent civic-tech prototype · inspired by Swachh Bharat · not an official government site</span>
      <h1 className="text-4xl md:text-6xl font-bold tracking-tight mt-4">India's <span className="text-brand">Smart Sanitation</span> Network</h1>
      <p className="text-xl mt-3 max-w-2xl text-slate-500">From Complaint Management to <b className="text-saffron">Real-Time Sanitation Operations</b>.</p>
      <div className="flex gap-2 mt-5"><button className="btn pri" onClick={() => { d.next(); document.getElementById("demo")?.scrollIntoView({ behavior: "smooth" }); }}>▶ Start Demo Mode</button><button className="btn" onClick={() => go("citizen")}>Citizen app</button></div></section>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4"><Kpi v={4212 + done} l="resolved this month" /><Kpi v={done ? "10.8 min" : "11.2 min"} l="avg response" /><Kpi v="1,140" l="verified workers" /><Kpi v="96%" l="within SLA" /></div>
    <h2 id="demo" className="text-2xl font-semibold mt-10 mb-3">Live city map & Demo Mode</h2>
    <div className="grid md:grid-cols-2 gap-4"><div className="card"><CityMap step={d.step} /></div><div className="card"><Controls d={d} /><Timeline d={d} /></div></div>
    <div className="grid md:grid-cols-3 gap-4 mt-10">{[[Navigation, "Real-time coordination", "GPS matching, ETA, route optimisation and workload balancing."], [BadgeCheck, "Verified workforce", "Masked ID + “Government ID Verified” badge. No Aadhaar stored."], [Brain, "CleanAI", "Spots repeat complaints and hotspots, schedules preventive cleaning."], [Timer, "SLA & escalation", "Configurable timers auto-escalate unresponsive tasks."], [WifiOff, "Offline-first worker app", "Tasks and proof photos sync when back online."], [Star, "Digital proof", "Before/after photos, supervisor check, citizen rating."]].map(([I, t, s]: any) => <div key={t} className="card"><I className="text-brand mb-2" /><h3 className="font-semibold">{t}</h3><p className="text-sm text-slate-500">{s}</p></div>)}</div></>);
}
function CitizenV({ d }: { d: D }) {
  const [pin, setPin] = useState<[number, number] | null>(null);
  const status = d.step >= 7 ? "Completed" : d.step >= 6 ? "Work Started" : d.step >= 5 ? "On the Way · ETA 6 min" : "Accepted";
  return (<div className="grid md:grid-cols-2 gap-4"><div className="card"><h2 className="font-semibold text-lg">New request</h2>
    <select className="border rounded-xl p-2 my-2 w-full bg-transparent" aria-label="Service">{["Drainage cleaning", "Garbage collection", "Street cleaning", "Dry waste", "Wet waste", "Report issue"].map(x => <option key={x}>{x}</option>)}</select>
    <p className="text-sm mb-2">Tap map to set location · <Chip>Wet</Chip> <Chip>Dry</Chip> <Chip warn>Hazardous</Chip></p>
    <CityMap step={d.step} pin={pin} onPick={setPin} h={300} /><button className="btn pri mt-3" onClick={() => { setPin(pin ?? END); d.set(3); }}>Request nearest worker</button></div>
    <div className="card"><h2 className="font-semibold text-lg">Active request</h2>{d.step < 3 ? <p className="text-slate-500">None yet. Submit one or run Demo Mode.</p> : <><p className="my-2"><Chip>{status}</Chip></p><p>Ravi K. · ⭐ 4.8 · <BadgeCheck className="inline h-4 w-4 text-brand" /> Govt ID Verified</p>
      {d.step >= 7 && <div className="grid grid-cols-2 gap-2 my-3"><div className="h-20 rounded-xl bg-emerald-100 grid place-items-center text-sm text-emerald-900">Before</div><div className="h-20 rounded-xl bg-emerald-100 grid place-items-center text-sm text-emerald-900">After</div></div>}
      {d.step >= 8 && <p>Rate: {[1, 2, 3, 4, 5].map(i => <button key={i} aria-label={`${i} stars`} className="text-xl" onClick={() => d.set(9)}>{d.step >= 9 || false ? "★" : "☆"}</button>)}</p>}</>}
      <h3 className="font-semibold mt-4">Notifications</h3><p className="text-sm">{d.step >= 8 ? "✅ Work verified" : d.step >= 5 ? "🚶 Worker on the way" : "🔔 Ward 12 drive on Sunday"}</p>
      <h3 className="font-semibold mt-4">History</h3><p className="text-sm text-slate-500">#2041 Garbage ✓ ★4 · #1988 Street ✓ ★5</p></div></div>);
}
function WorkerV({ d }: { d: D }) {
  const [on, setOn] = useState(true), [off, setOff] = useState(false);
  const st = ["Accepted", "On the Way", "Arrived", "Work Started", "Completed"], cur = Math.min(4, d.step - 4);
  return (<div className="grid md:grid-cols-2 gap-4"><div className="card"><h2 className="font-semibold text-lg">Ravi K.</h2><p className="my-2"><Chip><BadgeCheck className="inline h-3 w-3" /> Government ID Verified</Chip> <Chip>ID ••••-••••-4821</Chip></p><p className="text-sm text-slate-500">Ward 12 · Zone B · 3/6 tasks</p>
    <div className="flex gap-2 my-3"><button className={`btn ${on ? "bg-brand text-white" : ""}`} onClick={() => setOn(!on)}>{on ? "● Available" : "○ Unavailable"}</button><button className="btn" onClick={() => setOff(!off)}>{off ? <WifiOff className="inline h-4 w-4" /> : <Wifi className="inline h-4 w-4" />} {off ? "Offline · 2 queued" : "Online"}</button></div>
    {d.step < 3 ? <p className="text-slate-500">No task. Start Demo Mode.</p> : <><p className="font-medium">Blocked drain, Sector 4</p><div className="flex flex-wrap gap-1 my-2">{st.map((x, i) => <span key={x} className={`chip ${i > cur ? "!bg-orange-100 !text-orange-800" : ""}`}>{i <= cur && "✓ "}{x}</span>)}</div>
      <button className="btn pri" disabled={d.step >= 7} onClick={d.step < 4 ? () => d.set(4) : d.next}>{d.step < 4 ? "Accept task" : "Advance status →"}</button></>}
    <h3 className="font-semibold mt-4">Calendar</h3><p className="text-sm text-slate-500">08:00 Wet waste ✓ · 10:30 Drain {d.step >= 7 ? "✓" : "⏳"} · 14:00 CleanAI preventive clean</p></div>
    <div className="card"><CityMap step={d.step} h={380} /></div></div>);
}
function SupV({ d }: { d: D }) {
  return (<><div className="card overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-left"><th>Task</th><th>Worker</th><th>SLA</th><th>Status</th><th></th></tr></thead><tbody>
    <tr className="border-t"><td>Drain, Sector 4</td><td>Ravi K.</td><td>{d.step >= 7 ? "Met" : "42:10"}</td><td><Chip>{d.step >= 8 ? "Verified" : d.step >= 7 ? "Awaiting verification" : d.step >= 5 ? "In progress" : "Assigned"}</Chip></td><td><button className="btn pri" disabled={d.step < 7 || d.step >= 8} onClick={d.next}>Verify proof</button></td></tr>
    <tr className="border-t"><td>Bin overflow, Lane 9</td><td><select className="border rounded p-1 bg-transparent"><option>Asha</option><option>Kiran</option></select></td><td className="text-red-600">Overdue 05:12</td><td><Chip warn>Escalated</Chip></td><td><button className="btn">Reassign</button></td></tr></tbody></table></div>
    <div className="card mt-4"><p className="font-semibold">Workload balancing</p><p className="text-sm text-slate-500">Asha 2 · Ravi 3 · Kiran 4 · Devi 1 → next task suggested to Devi</p></div></>);
}
function AdminV({ d }: { d: D }) {
  const done = d.step >= 10 ? 1 : 0;
  const cat = [{ n: "Garbage", v: 42 }, { n: "Drainage", v: 28 + done }, { n: "Street", v: 19 }, { n: "Dry/Wet", v: 15 }, { n: "Other", v: 9 }];
  const rt = [12.4, 11.9, 11.6, 11.2, done ? 10.8 : 11.2].map((v, i) => ({ d: ["Mon", "Tue", "Wed", "Thu", "Fri"][i], v }));
  return (<><div className="grid grid-cols-2 md:grid-cols-4 gap-4"><Kpi v={128 + done} l="resolved today" /><Kpi v={done ? "10.8 min" : "11.2 min"} l="avg response" /><Kpi v="94%" l="SLA compliance" /><Kpi v="37" l="workers active" /></div>
    <div className="grid md:grid-cols-2 gap-4 mt-4"><div className="card h-72"><ResponsiveContainer><BarChart data={cat}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="n" /><YAxis /><Tooltip /><Bar dataKey="v" fill="#0b6b3a" radius={[8, 8, 0, 0]} /></BarChart></ResponsiveContainer></div>
      <div className="card h-72"><ResponsiveContainer><LineChart data={rt}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="d" /><YAxis domain={[10, 13]} /><Tooltip /><Line dataKey="v" stroke="#f28c28" strokeWidth={3} /></LineChart></ResponsiveContainer></div></div>
    <div className="grid md:grid-cols-2 gap-4 mt-4"><div className="card"><h3 className="font-semibold"><Brain className="inline h-4 w-4" /> CleanAI</h3><p className="text-sm mt-2">Hotspot: Ward 13 market bins, 7 complaints/14 days. Suggest preventive cleaning Tue/Fri 06:00 and 1 extra bin.</p>{done ? <p className="text-sm mt-2">New: Sector 4 drain flagged for desilting.</p> : null}
      <h3 className="font-semibold mt-4">SLA settings</h3><label className="text-sm">Response (min) <input type="number" defaultValue={10} className="border rounded p-1 w-20 bg-transparent" /></label></div><div className="card"><CityMap step={d.step} h={260} /></div></div></>);
}
export default function App() {
  const [v, setV] = useState("home"); const d = useDemo();
  return (<><header className="sticky top-0 z-[1000] backdrop-blur bg-white/80 dark:bg-[#0b1220]/80 border-b"><div className="max-w-6xl mx-auto px-4 py-2 flex items-center gap-3 flex-wrap"><span className="font-bold text-lg flex items-center gap-2 mr-auto"><Leaf className="text-brand" />CleanConnect</span>
    <nav className="flex gap-1 overflow-x-auto">{TABS.map(([k, l, I]) => <button key={k} onClick={() => setV(k)} className={`btn ${v === k ? "!bg-brand !text-white" : ""}`}><I className="inline h-4 w-4 mr-1" />{l}</button>)}</nav></div></header>
    <main className="max-w-6xl mx-auto px-4 pb-16 pt-4">{v === "home" && <HomeV d={d} go={setV} />}{v === "citizen" && <CitizenV d={d} />}{v === "worker" && <WorkerV d={d} />}{v === "sup" && <SupV d={d} />}{v === "admin" && <AdminV d={d} />}</main></>);
}
