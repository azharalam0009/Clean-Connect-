import { useEffect, useState } from "react";
import { MapContainer, TileLayer, CircleMarker, Circle, Polyline, Tooltip, useMapEvents } from "react-leaflet";
import "leaflet/dist/leaflet.css";
type P = [number, number];
export const START: P = [26.918, 75.775], END: P = [26.905, 75.793];
const workers: [string, P][] = [["Asha", [26.912, 75.78]], ["Imran", [26.9, 75.8]], ["Devi", [26.925, 75.79]], ["Kiran", [26.908, 75.768]]];
const complaints: [string, P][] = [["Overflowing bin", [26.914, 75.77]], ["Street litter", [26.92, 75.8]], ["Drain smell", [26.897, 75.78]]];
const zones: [string, P, string][] = [["Ward 12", [26.91, 75.785], "#0b6b3a"], ["Ward 13", [26.895, 75.765], "#f28c28"]];
function Pick({ onPick }: { onPick: (p: P) => void }) { useMapEvents({ click: e => onPick([e.latlng.lat, e.latlng.lng]) }); return null; }
export default function CityMap({ step, pin, onPick, h = 420 }: { step: number; pin?: P | null; onPick?: (p: P) => void; h?: number }) {
  const [k, setK] = useState(0);
  useEffect(() => { if (step < 5) { setK(0); return; } const id = setInterval(() => setK(v => Math.min(1, v + 0.05)), 200); return () => clearInterval(id); }, [step]);
  const rv: P = [START[0] + (END[0] - START[0]) * k, START[1] + (END[1] - START[1]) * k];
  return (
    <MapContainer center={[26.91, 75.786]} zoom={13} style={{ height: h, borderRadius: 16 }} scrollWheelZoom={false}>
      <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {onPick && <Pick onPick={onPick} />}
      {zones.map(([n, c, col]) => <Circle key={n} center={c} radius={1200} pathOptions={{ color: col, fillOpacity: 0.08 }}><Tooltip>{n} · sanitation zone</Tooltip></Circle>)}
      <Circle center={[26.897, 75.78]} radius={500} pathOptions={{ color: "#e33", fillOpacity: 0.2 }}><Tooltip>CleanAI hotspot</Tooltip></Circle>
      {complaints.map(([n, c]) => <CircleMarker key={n} center={c} radius={7} pathOptions={{ color: "#e33" }}><Tooltip>{n}</Tooltip></CircleMarker>)}
      {workers.map(([n, c]) => <CircleMarker key={n} center={c} radius={7} pathOptions={{ color: "#0b6b3a", fillOpacity: 1 }}><Tooltip>{n} · available</Tooltip></CircleMarker>)}
      {pin && <CircleMarker center={pin} radius={9} pathOptions={{ color: "#f28c28", fillOpacity: 1 }}><Tooltip permanent>Your location</Tooltip></CircleMarker>}
      {step >= 2 && <CircleMarker center={END} radius={10} pathOptions={{ color: "#f28c28", fillOpacity: 1 }}><Tooltip>Drain request</Tooltip></CircleMarker>}
      {step >= 3 && step < 7 && <Polyline positions={[START, END]} pathOptions={{ color: "#0b6b3a", dashArray: "8 8" }} />}
      {step >= 3 && <CircleMarker center={rv} radius={12} pathOptions={{ color: "#fff", fillColor: "#0b6b3a", fillOpacity: 1, weight: 3 }}><Tooltip permanent>Ravi K.{step === 5 ? " · ETA 6m" : ""}</Tooltip></CircleMarker>}
    </MapContainer>);
}
