export default { content:["./index.html","./src/**/*.{ts,tsx}"], darkMode:"media",
 theme:{extend:{colors:{brand:"#0b6b3a",saffron:"#f28c28",navy:"#0f1b3d"}}}, plugins:[] };
