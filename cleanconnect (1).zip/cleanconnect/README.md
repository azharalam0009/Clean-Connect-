# CleanConnect
React + TypeScript + Vite + Tailwind + Leaflet/OSM + Recharts + Lucide. Simulated demo data; independent prototype, not an official government site.
## Run
npm install && npm run dev
## GitHub
git init && git add . && git commit -m "CleanConnect" && git branch -M main
git remote add origin https://github.com/<you>/cleanconnect.git && git push -u origin main
## Netlify
Add new site > Import from GitHub. Build: `npm run build`, publish: `dist` (already in netlify.toml).
